<%-- 
    Document   : Calculo
    Created on : 29 ene. 2026, 11:11:31
    Author     : Alumno
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">

<f:view>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <title>JSP Page</title>
        </head>
        <body>
            <<form action="calculo.jsp">
                Nombre<input type="text" name="name"><br>
                Edad<input type="text" name="edad"><br>
                <input type="submit" value="Enviar"><br>
            </form>
            
            <%
                String cadena1;
                int Edad;
                cadena1 = request.getParameter("name");
                Edad = Integer.parseInt(request.getParameter("age"));
                //Edad = request.getParameter("edad");
                if (Edad >= 18)
                out.println("Eres mayor de edad");
                if (Edad < 18)
                out.println("Eres menor de edad");
                out.println(cadena1);
                %>
        </body>
    </html>
</f:view>
