<%-- 
    Document   : Calculo
    Created on : 5 feb. 2026, 10:51:11
    Author     : Alumno
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <table>
                <form action="Calculo.jsp">
                    <tr>
                        <th>Nombre</th>
                        <th>Edad</th>
                    </tr>
                    <tr>
                        <td><input type="text" name="name"><br></td>
                        <td><input type="text" name="age"><br></td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Enviar"><br></td>
                    </tr>
                </form>
            </table>
            
            <%
                try{
                    String cadena1;
                    int Edad;
                    cadena1 = request.getParameter("name");
                    Edad = Integer.parseInt(request.getParameter("age"));
                    //Edad = request.getParameter("edad");
                    if (Edad >= 18)
                    out.println("Eres mayor de edad");
                    if (Edad < 18)
                    out.println("Eres menor de edad");
                    out.println(cadena1);
                } catch (ArrayIndexOutOfBoundsException e) {
                    out.println("Hubo un error");
                }
            %>
    </body>
</html>
