<%-- 
    Document   : Multiplicar
    Created on : 5 feb. 2026, 10:56:04
    Author     : Alumno
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Multiplicación</h1>
        
        <form action="Multiplicar.jsp">
            <table>
                <tr>
                    <th>Numero 1</th>
                    <th>Numero 2</th>
                </tr>
                <tr>
                    <td><input type="text" name="No1"><br></td>
                    <td><input type="text" name="No2"><br></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Multiplicar"><br></td>
                </tr>
            </table>
        </form>
        
        <%
            try {
                int num1, num2;
                
                num1 = Integer.parseInt(request.getParameter("No1"));
                num2 = Integer.parseInt(request.getParameter("No2"));

                for (int fila = 1; fila <= num1; fila++) {
                    for (int columna = 1; columna <= num2; columna++) {
                        //out.println((fila * columna) /*+ "<table><tr><td>" + fila + "</td/></tr>"*/);
                        out.println("<table><tr>"+(columna)+"</tr></table>");
                    }
                    out.println("<br>");
                    out.println("<table><tr>"+(fila)+"</tr></table>");
                }

            } catch (NumberFormatException e) {
                out.println("<br><br>Por favor, ingresa solo números.");
            }
        %>
        
    </body>
</html>
