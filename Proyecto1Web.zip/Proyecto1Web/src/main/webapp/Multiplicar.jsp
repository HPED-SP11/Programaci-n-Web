<%-- 
    Document   : Multiplicar
    Created on : 5 feb 2026, 9:46:46 p.m.
    Author     : hpede
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Programa multiplicaciones<br><br></h1>
        <form action="Multiplicar.jsp">
            <table>
                <tr>
                    <th>Número 1</th>
                    <th>Número 2</th>
                </tr>
                <tr>
                    <td><input type="text" name="No1"></td>
                    <td><input type="text" name="No2"></td>
                </tr>
                <tr><td><input type="submit" value="Multiplicar"></td></tr>
            </table>
            <br>
        </form>
        
        <%
            try{
                int Num1, Num2;
                Num1 = Integer.parseInt(request.getParameter("No1"));
                Num2 = Integer.parseInt(request.getParameter("No2"));
                
                out.println("<table border='1'>");
                for(int fila = 1; fila <= Num1; fila++){
                    out.println("<tr>");
                    for(int columna = 1; columna <= Num2; columna++){
                        out.println("<td style='padding:0.2rem'>"+(fila*columna)+"</td>");
                    }
                    out.println("</td>");
                }
                out.println("</table>");
            } catch(Exception e) {
                out.println("<br>Por favor, ingresa números enteros.");
            }
        %>
        <footer><br><br>05 de febrero de 2026, Hernández Pérez Edgar Daniel</footer>
    </body>
</html>
