<%-- 
    Document   : calculo
    Created on : 29 ene 2026, 7:17:40 p.m.
    Author     : hpede
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Formulario Básico</title>
    </head>
    <body>
        <!-- Edgar Daniel Hernández Pérez, 221770108 -->
        <table border="2">
            <form action="calculo.jsp">
                <tr>
                    <td>Nombre</td><td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td>Edad</td><td><input type="text" name="age"></td>
                </tr><br>
                <tr>
                    <td><input type="submit" value="Enviar"></td>
                </tr>
            </form>
        </table>
        
        <%
            String cadena1;
            int edad;
            cadena1 = request.getParameter("name");
            try {
                edad = Integer.parseInt(request.getParameter("age"));
                out.println("<br>Hola, " + cadena1);
                if(edad>=18)
                out.println("<br>Eres mayor de edad, tienes " + edad + " años");
                else if(edad<18)
                out.println("<br>Eres menor de edad, tienes " + edad + "años");
            } catch(NumberFormatException e){
                out.println("<br>Primero necesitas ingresar cual es tu edad, por favor");
            }
        %>
    </body>
</html>
