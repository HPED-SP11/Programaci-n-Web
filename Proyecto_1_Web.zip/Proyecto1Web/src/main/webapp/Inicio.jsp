<%-- 
    Document   : Inicio
    Created on : 9 feb 2026, 10:42:31
    Author     : Edgar Daniel Hernández Pérez
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action="Controlador.jsp">
            <table>
                <tr>
                    <th>Usuario: </th>
                    <td><input type="text" name="user"></td>
                </tr>
                <tr>
                    <th>Contraseña: </th>
                    <td><input type="text" name="psswd"></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Ingresar"></td>
                    <td><input type="submit" value="Borrar"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
