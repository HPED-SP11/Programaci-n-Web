<%-- 
    Document   : Controlador
    Created on : 9 feb 2026, 11:28:23
    Author     : Alumno
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
            try {

                String usuario1 = "Juan";
                String passwrd1 = "Admin";
                boolean admin1 = true;
                
                String usuario2 = "Pedro";
                String passwrd2 = "NoAdmin";
                boolean admin2 = false;
                
                usuario1 = request.getParameter("user");
                passwrd1 = request.getParameter("psswd");
                
                usuario2 = request.getParameter("user");
                passwrd2 = request.getParameter("psswd");
                
                if(request.getParameter("user").equals(usuario1 = "Juan") && request.getParameter("psswd").equals(passwrd1 = "Admin")) {
                    response.sendRedirect("RespuestaAdmin.jsp");
                } else if(request.getParameter("user").equals(usuario2 = "Pedro") && request.getParameter("psswd").equals(passwrd2 = "NoAdmin")) {
                    response.sendRedirect("RespuestaNoAdmin.jsp");
                } else {
                    out.println("<br><br>Ingresaste datos erroneos");
                }

        } catch(Exception e) {
            out.println("<br><br>Ingresa tus credenciales");
        }
        %>
        
        <!-- if((admin1 == true) || (admin2 == true)) {
                    boolean admin = true;
                    if((request.getParameter("user") == usuario1 && request.getParameter("psswd") == passwrd1) || (request.getParameter("user") == usuario2 && request.getParameter("psswd") == passwrd2)) {
                        response.sendRedirect("RespuestaAdmin.jsp");
                    }
                } else if((admin1 != true) || (admin2 != true)){
                    boolean admin = false;
                    if((request.getParameter("user") == usuario1 && request.getParameter("psswd") == passwrd1) || (request.getParameter("user") == usuario2 && request.getParameter("psswd") == passwrd2)) {
                        response.sendRedirect("RespuestaNoAdmin.jsp");
                    }
                } else {
                    out.println("<br><br>Ingresaste datos erroneos");
                }-->
    </body>
</html>
