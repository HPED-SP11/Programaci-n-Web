<%-- 
    Document   : RespuestaAdmin
    Created on : 9 feb 2026, 10:42:41
    Author     : Edgar Daniel Hernández Pérez
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hola Administrador</h1>
    </body>
</html>
