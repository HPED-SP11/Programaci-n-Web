<%-- 
    Document   : LogicForm
    Created on : 12 feb. 2026, 11:27:16
    Author     : Alumno
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <% 
            String resp1 = request.getParameter("P1");
            String resp2 = request.getParameter("P2");
            String resp3 = request.getParameter("P3");
            String resp4 = request.getParameter("P4");
            String resp5 = request.getParameter("P5");
            
            if(request.getParameter("P1").equals(request.getParameterValues(resp1 = "1"))) {
                response.sendRedirect("Examen.jsp");
                out.println("Correcto");
                out.println("<style>.Correcto {font-color:'green'} </style>");
            }
         %>
    </body>
</html>
