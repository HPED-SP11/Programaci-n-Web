<%-- 
    Document   : Examen
    Created on : 12 feb. 2026, 10:32:28
    Author     : Alumno
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Google+Sans:ital,opsz,wght@0,17..18,400..700;1,17..18,400..700&display=swap" rel="stylesheet">
        <style>body {font-family: 'Google Sans', sans-serif; font-optical-sizing: auto; margin: 1.2rem;}</style>
    </head>
    <body>
        <h1>Bienvenido/a al examen!</h1>
        
        <form action="LogicForm.jsp"> <!<!-- https://www.cisacad.net/ccna-1-v7-modulos-1-3-examen-de-conectividad-de-red-basica-y-comunicaciones-respuestas/ -->
            <p>1. Un empleado de una sucursal está realizando una cotización para un cliente. Para ello, necesita acceder a la información confidencial sobre precios que se encuentra en los servidores internos de la oficina central. ¿A qué tipo de red debería acceder el empleado?</p>
            <input type="radio" name="P1" value="internet">Internet<BR>
            <input type="radio" name="P1" value="intranet" class="Correcto">Una intranet<BR>
            <input type="radio" name="P1" value="lan">Una red de área local<BR>
            <input type="radio" name="P1" value="extranet">Una extranet<BR>
            
            <p>2. ¿Cuáles son los dos criterios que se utilizan para seleccionar un medio de red entre varios medios de red? (<B>Elija dos opciones</B>).</p>
            <input type="checkbox" name="P2" value="distancia">La distancia que el medio seleccionado puede transportar una señal correctamente<BR>
            <input type="checkbox" name="P2" value="cantidad">La cantidad de dispositivos intermedios instalados en la red<BR>
            <input type="checkbox" name="P2" value="costo">El costo de los dispositivos finales que se utilizan en la red<BR>
            <input type="checkbox" name="P2" value="1">El entorno en el que se debe instalar el medio seleccionado<BR>
            <input type="checkbox" name="P2">Los tipos de datos que se deben priorizar<BR>
            
            <p>3. Un usuario está implementando una política de seguridad en una red de oficina pequeña. ¿Cuáles son las dos acciones que proporcionarían los requisitos mínimos de seguridad para esta red? (<B>Elija dos opciones</B>).</p>
            <input type="checkbox" name="P3">La implementación de un sistema de detección de intrusiones<BR>
            <input type="checkbox" name="P3">La instalación de una red inalámbrica<BR>
            <input type="checkbox" name="P3" value="1">La implementación de un firewall<BR>
            <input type="checkbox" name="P3">El agregado de un dispositivo de prevención de intrusiones exclusivo<BR>
            <input type="checkbox" name="P3" value="1">La instalación de un software antivirus<BR>
            
            <p>4. ¿Cuál de estas interfaces permite la administración remota de un switch de capa 2?</p>
            <input type="radio" name="P4">La primera interfaz de puerto Ethernet<BR>
            <input type="radio" name="P4">La interfaz de puerto de consola<BR>
            <input type="radio" name="P4" value="1">La interfaz virtual del switch<BR>
            <input type="radio" name="P4">La interfaz auxiliar<BR>
            
            <p>5. ¿Qué función tiene la tecla de tabulación al introducir un comando en IOS?</p>
            <input type="radio" name="P5">Desplaza el cursor hacia el principio de la línea siguiente.<BR>
            <input type="radio" name="P5" value="1">Completa el resto de una palabra escrita parcialmente en un comando.<BR>
            <input type="radio" name="P5">Anula el comando actual y vuelve al modo de configuración<BR>
            <input type="radio" name="P5">Sale del modo de configuración y vuelve al modo EXEC del usuario.<BR>
            
            <input type="submit" value="Revisar" name="check">
        </form>
        
    </body>
</html>
